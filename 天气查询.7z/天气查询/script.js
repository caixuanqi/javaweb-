const resultBox = document.getElementById("resultBox");
const queryBtn = document.getElementById("queryBtn");
const cityInput = document.getElementById("cityInput");

// 万维易源API配置（需替换为您的APP Key）
const APP_KEY = "44740312D062497f8820Abad3abf4732";
const API_URL = "https://route.showapi.com/9-2";

async function getWeather() {
    const city = cityInput.value.trim();
    if (!city) {
        resultBox.innerHTML = "请输入城市名称";
        return;
    }

    // 构造请求参数（根据API文档）
    const params = new URLSearchParams();
    params.append("area", city); // 地区名称（必填其一）
    params.append("appKey", APP_KEY); // API密钥
    params.append("needMoreDay", "0"); // 不需要7天数据
    params.append("needIndex", "0"); // 不需要指数数据
    params.append("need3HourForcast", "0"); // 不需要3小时间隔预报
    params.append("needAlarm", "1"); // 需要天气预警（可选）
    params.append("needHourData", "0"); // 不需要每小时数据

    try {
        resultBox.innerHTML = "查询中...";
        resultBox.classList.add("loading");

        const response = await fetch(API_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: params.toString()
        });

        if (!response.ok) {
            throw new Error(`网络请求失败，状态码：${response.status}`);
        }

        const data = await response.json();

        // 检查API返回状态（关键！）
        if (data.showapi_res_code !== 0) {
            throw new Error(`API返回错误：${data.showapi_res_error || "未知错误"}`);
        }

        if (data.showapi_res_body.ret_code !== 0) {
            throw new Error(`业务逻辑错误：${data.showapi_res_body.ret_msg || "未知错误"}`);
        }

        // 解析并展示天气数据（根据返回格式）
        const weatherInfo = data.showapi_res_body;
        const html = `
            <strong>${city} 实时天气</strong><br>
            ---------------------------<br>
            当前温度：${weatherInfo.now.temperature}℃<br>
            天气状况：${weatherInfo.now.weather}<br>
            湿度：${weatherInfo.now.sd}<br>
            风向：${weatherInfo.now.wind_direction}<br>
            风力：${weatherInfo.now.wind_power}<br>
            ---------------------------<br>
            今日预报（${weatherInfo.f1.day_weather}）<br>
            白天温度：${weatherInfo.f1.day_air_temperature}℃<br>
            夜间温度：${weatherInfo.f1.night_air_temperature}℃<br>
            ---------------------------<br>
            ${weatherInfo.alarmList.length > 0 ? "⚠️ 天气预警：" : ""}
            ${weatherInfo.alarmList.map(alarm =>
            `${alarm.issueTime} ${alarm.province}${alarm.city} ${alarm.signalType}：${alarm.issueContent}<br>`
        ).join("")}
        `;

        resultBox.innerHTML = html;
        resultBox.classList.remove("loading");
    } catch (error) {
        resultBox.innerHTML = `查询失败：${error.message}`;
        resultBox.classList.remove("loading");
        console.error("天气查询错误：", error);
    }
}